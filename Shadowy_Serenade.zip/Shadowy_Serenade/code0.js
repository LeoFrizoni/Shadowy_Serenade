gdjs.Main_95menuCode = {};
gdjs.Main_95menuCode.localVariables = [];
gdjs.Main_95menuCode.GDtitleObjects1= [];
gdjs.Main_95menuCode.GDtitleObjects2= [];
gdjs.Main_95menuCode.GDtitleObjects3= [];
gdjs.Main_95menuCode.GDplayObjects1= [];
gdjs.Main_95menuCode.GDplayObjects2= [];
gdjs.Main_95menuCode.GDplayObjects3= [];
gdjs.Main_95menuCode.GDquitObjects1= [];
gdjs.Main_95menuCode.GDquitObjects2= [];
gdjs.Main_95menuCode.GDquitObjects3= [];
gdjs.Main_95menuCode.GDsettingsObjects1= [];
gdjs.Main_95menuCode.GDsettingsObjects2= [];
gdjs.Main_95menuCode.GDsettingsObjects3= [];
gdjs.Main_95menuCode.GDsoundObjects1= [];
gdjs.Main_95menuCode.GDsoundObjects2= [];
gdjs.Main_95menuCode.GDsoundObjects3= [];
gdjs.Main_95menuCode.GDsound_9595sliderObjects1= [];
gdjs.Main_95menuCode.GDsound_9595sliderObjects2= [];
gdjs.Main_95menuCode.GDsound_9595sliderObjects3= [];
gdjs.Main_95menuCode.GDmusicObjects1= [];
gdjs.Main_95menuCode.GDmusicObjects2= [];
gdjs.Main_95menuCode.GDmusicObjects3= [];
gdjs.Main_95menuCode.GDmusic_9595sliderObjects1= [];
gdjs.Main_95menuCode.GDmusic_9595sliderObjects2= [];
gdjs.Main_95menuCode.GDmusic_9595sliderObjects3= [];
gdjs.Main_95menuCode.GDbackObjects1= [];
gdjs.Main_95menuCode.GDbackObjects2= [];
gdjs.Main_95menuCode.GDbackObjects3= [];
gdjs.Main_95menuCode.GDmarker_9595menuObjects1= [];
gdjs.Main_95menuCode.GDmarker_9595menuObjects2= [];
gdjs.Main_95menuCode.GDmarker_9595menuObjects3= [];
gdjs.Main_95menuCode.GDmarker_9595settingsObjects1= [];
gdjs.Main_95menuCode.GDmarker_9595settingsObjects2= [];
gdjs.Main_95menuCode.GDmarker_9595settingsObjects3= [];
gdjs.Main_95menuCode.GDmarker_9595level_9595selectObjects1= [];
gdjs.Main_95menuCode.GDmarker_9595level_9595selectObjects2= [];
gdjs.Main_95menuCode.GDmarker_9595level_9595selectObjects3= [];
gdjs.Main_95menuCode.GDlevel_95951Objects1= [];
gdjs.Main_95menuCode.GDlevel_95951Objects2= [];
gdjs.Main_95menuCode.GDlevel_95951Objects3= [];
gdjs.Main_95menuCode.GDlevel_95952Objects1= [];
gdjs.Main_95menuCode.GDlevel_95952Objects2= [];
gdjs.Main_95menuCode.GDlevel_95952Objects3= [];
gdjs.Main_95menuCode.GDlevel_95953Objects1= [];
gdjs.Main_95menuCode.GDlevel_95953Objects2= [];
gdjs.Main_95menuCode.GDlevel_95953Objects3= [];
gdjs.Main_95menuCode.GDlevel_95954Objects1= [];
gdjs.Main_95menuCode.GDlevel_95954Objects2= [];
gdjs.Main_95menuCode.GDlevel_95954Objects3= [];
gdjs.Main_95menuCode.GDback2Objects1= [];
gdjs.Main_95menuCode.GDback2Objects2= [];
gdjs.Main_95menuCode.GDback2Objects3= [];
gdjs.Main_95menuCode.GDcontrollers_9595infoObjects1= [];
gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2= [];
gdjs.Main_95menuCode.GDcontrollers_9595infoObjects3= [];
gdjs.Main_95menuCode.GDmarker_9595controllerObjects1= [];
gdjs.Main_95menuCode.GDmarker_9595controllerObjects2= [];
gdjs.Main_95menuCode.GDmarker_9595controllerObjects3= [];
gdjs.Main_95menuCode.GDArrowKeyObjects1= [];
gdjs.Main_95menuCode.GDArrowKeyObjects2= [];
gdjs.Main_95menuCode.GDArrowKeyObjects3= [];
gdjs.Main_95menuCode.GDArrowKey2Objects1= [];
gdjs.Main_95menuCode.GDArrowKey2Objects2= [];
gdjs.Main_95menuCode.GDArrowKey2Objects3= [];
gdjs.Main_95menuCode.GDLetterKeyObjects1= [];
gdjs.Main_95menuCode.GDLetterKeyObjects2= [];
gdjs.Main_95menuCode.GDLetterKeyObjects3= [];
gdjs.Main_95menuCode.GDSpaceKeyObjects1= [];
gdjs.Main_95menuCode.GDSpaceKeyObjects2= [];
gdjs.Main_95menuCode.GDSpaceKeyObjects3= [];
gdjs.Main_95menuCode.GDcontrollers_9595moveObjects1= [];
gdjs.Main_95menuCode.GDcontrollers_9595moveObjects2= [];
gdjs.Main_95menuCode.GDcontrollers_9595moveObjects3= [];
gdjs.Main_95menuCode.GDcontrollers_9595jumpObjects1= [];
gdjs.Main_95menuCode.GDcontrollers_9595jumpObjects2= [];
gdjs.Main_95menuCode.GDcontrollers_9595jumpObjects3= [];
gdjs.Main_95menuCode.GDcontrollers_9595attackObjects1= [];
gdjs.Main_95menuCode.GDcontrollers_9595attackObjects2= [];
gdjs.Main_95menuCode.GDcontrollers_9595attackObjects3= [];
gdjs.Main_95menuCode.GDback3Objects1= [];
gdjs.Main_95menuCode.GDback3Objects2= [];
gdjs.Main_95menuCode.GDback3Objects3= [];
gdjs.Main_95menuCode.GDauthorsObjects1= [];
gdjs.Main_95menuCode.GDauthorsObjects2= [];
gdjs.Main_95menuCode.GDauthorsObjects3= [];
gdjs.Main_95menuCode.GDmarker_9595autorsObjects1= [];
gdjs.Main_95menuCode.GDmarker_9595autorsObjects2= [];
gdjs.Main_95menuCode.GDmarker_9595autorsObjects3= [];
gdjs.Main_95menuCode.GDauthors_9595textObjects1= [];
gdjs.Main_95menuCode.GDauthors_9595textObjects2= [];
gdjs.Main_95menuCode.GDauthors_9595textObjects3= [];
gdjs.Main_95menuCode.GDback4Objects1= [];
gdjs.Main_95menuCode.GDback4Objects2= [];
gdjs.Main_95menuCode.GDback4Objects3= [];
gdjs.Main_95menuCode.GDplayer_9595hudObjects1= [];
gdjs.Main_95menuCode.GDplayer_9595hudObjects2= [];
gdjs.Main_95menuCode.GDplayer_9595hudObjects3= [];
gdjs.Main_95menuCode.GDlife_9595hudObjects1= [];
gdjs.Main_95menuCode.GDlife_9595hudObjects2= [];
gdjs.Main_95menuCode.GDlife_9595hudObjects3= [];
gdjs.Main_95menuCode.GDEnergyBarObjects1= [];
gdjs.Main_95menuCode.GDEnergyBarObjects2= [];
gdjs.Main_95menuCode.GDEnergyBarObjects3= [];
gdjs.Main_95menuCode.GDPortraitBackroundObjects1= [];
gdjs.Main_95menuCode.GDPortraitBackroundObjects2= [];
gdjs.Main_95menuCode.GDPortraitBackroundObjects3= [];
gdjs.Main_95menuCode.GDbackgroundObjects1= [];
gdjs.Main_95menuCode.GDbackgroundObjects2= [];
gdjs.Main_95menuCode.GDbackgroundObjects3= [];
gdjs.Main_95menuCode.GDSpikesObjects1= [];
gdjs.Main_95menuCode.GDSpikesObjects2= [];
gdjs.Main_95menuCode.GDSpikesObjects3= [];
gdjs.Main_95menuCode.GDplayerObjects1= [];
gdjs.Main_95menuCode.GDplayerObjects2= [];
gdjs.Main_95menuCode.GDplayerObjects3= [];
gdjs.Main_95menuCode.GDkeyObjects1= [];
gdjs.Main_95menuCode.GDkeyObjects2= [];
gdjs.Main_95menuCode.GDkeyObjects3= [];
gdjs.Main_95menuCode.GDcollisionObjects1= [];
gdjs.Main_95menuCode.GDcollisionObjects2= [];
gdjs.Main_95menuCode.GDcollisionObjects3= [];
gdjs.Main_95menuCode.GDCollisionCheckObjects1= [];
gdjs.Main_95menuCode.GDCollisionCheckObjects2= [];
gdjs.Main_95menuCode.GDCollisionCheckObjects3= [];
gdjs.Main_95menuCode.GDratObjects1= [];
gdjs.Main_95menuCode.GDratObjects2= [];
gdjs.Main_95menuCode.GDratObjects3= [];
gdjs.Main_95menuCode.GDrat_9595attackObjects1= [];
gdjs.Main_95menuCode.GDrat_9595attackObjects2= [];
gdjs.Main_95menuCode.GDrat_9595attackObjects3= [];
gdjs.Main_95menuCode.GDMenu_9595backgroundObjects1= [];
gdjs.Main_95menuCode.GDMenu_9595backgroundObjects2= [];
gdjs.Main_95menuCode.GDMenu_9595backgroundObjects3= [];


gdjs.Main_95menuCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("marker_menu"), gdjs.Main_95menuCode.GDmarker_9595menuObjects2);
gdjs.copyArray(runtimeScene.getObjects("marker_settings"), gdjs.Main_95menuCode.GDmarker_9595settingsObjects2);
gdjs.copyArray(runtimeScene.getObjects("music_slider"), gdjs.Main_95menuCode.GDmusic_9595sliderObjects2);
gdjs.copyArray(runtimeScene.getObjects("sound_slider"), gdjs.Main_95menuCode.GDsound_9595sliderObjects2);
{for(var i = 0, len = gdjs.Main_95menuCode.GDmarker_9595menuObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDmarker_9595menuObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_95menuCode.GDmarker_9595settingsObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDmarker_9595settingsObjects2[i].hide();
}
}{gdjs.evtTools.storage.readStringFromJSONFile("Settings", "Settings", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)), runtimeScene.getGame().getVariables().getFromIndex(1));
}{for(var i = 0, len = gdjs.Main_95menuCode.GDsound_9595sliderObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDsound_9595sliderObjects2[i].SetValue(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("Sound")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_95menuCode.GDmusic_9595sliderObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDmusic_9595sliderObjects2[i].SetValue(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("Music")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "bgm.ogg", 0, false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("Music")), 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("quit"), gdjs.Main_95menuCode.GDquitObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDquitObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDquitObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDquitObjects2[k] = gdjs.Main_95menuCode.GDquitObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDquitObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("authors"), gdjs.Main_95menuCode.GDauthorsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDauthorsObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDauthorsObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDauthorsObjects2[k] = gdjs.Main_95menuCode.GDauthorsObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDauthorsObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("marker_autors"), gdjs.Main_95menuCode.GDmarker_9595autorsObjects2);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.Main_95menuCode.GDmarker_9595autorsObjects2.length === 0 ) ? 0 :gdjs.Main_95menuCode.GDmarker_9595autorsObjects2[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("controllers_info"), gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2[k] = gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("marker_controller"), gdjs.Main_95menuCode.GDmarker_9595controllerObjects2);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.Main_95menuCode.GDmarker_9595controllerObjects2.length === 0 ) ? 0 :gdjs.Main_95menuCode.GDmarker_9595controllerObjects2[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "linear", "easeInOutQuad", 2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("settings"), gdjs.Main_95menuCode.GDsettingsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDsettingsObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDsettingsObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDsettingsObjects2[k] = gdjs.Main_95menuCode.GDsettingsObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDsettingsObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("marker_settings"), gdjs.Main_95menuCode.GDmarker_9595settingsObjects2);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.Main_95menuCode.GDmarker_9595settingsObjects2.length === 0 ) ? 0 :gdjs.Main_95menuCode.GDmarker_9595settingsObjects2[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("authors"), gdjs.Main_95menuCode.GDauthorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.Main_95menuCode.GDbackObjects2);
gdjs.copyArray(runtimeScene.getObjects("back2"), gdjs.Main_95menuCode.GDback2Objects2);
gdjs.copyArray(runtimeScene.getObjects("back3"), gdjs.Main_95menuCode.GDback3Objects2);
gdjs.copyArray(runtimeScene.getObjects("back4"), gdjs.Main_95menuCode.GDback4Objects2);
gdjs.copyArray(runtimeScene.getObjects("controllers_info"), gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2);
gdjs.copyArray(runtimeScene.getObjects("level_1"), gdjs.Main_95menuCode.GDlevel_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("level_2"), gdjs.Main_95menuCode.GDlevel_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("level_3"), gdjs.Main_95menuCode.GDlevel_95953Objects2);
gdjs.copyArray(runtimeScene.getObjects("level_4"), gdjs.Main_95menuCode.GDlevel_95954Objects2);
gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.Main_95menuCode.GDplayObjects2);
gdjs.copyArray(runtimeScene.getObjects("quit"), gdjs.Main_95menuCode.GDquitObjects2);
gdjs.copyArray(runtimeScene.getObjects("settings"), gdjs.Main_95menuCode.GDsettingsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDplayObjects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDplayObjects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDplayObjects2[k] = gdjs.Main_95menuCode.GDplayObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDplayObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDquitObjects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDquitObjects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDquitObjects2[k] = gdjs.Main_95menuCode.GDquitObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDquitObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDsettingsObjects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDsettingsObjects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDsettingsObjects2[k] = gdjs.Main_95menuCode.GDsettingsObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDsettingsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDbackObjects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDbackObjects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDbackObjects2[k] = gdjs.Main_95menuCode.GDbackObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDbackObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDlevel_95951Objects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDlevel_95951Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDlevel_95951Objects2[k] = gdjs.Main_95menuCode.GDlevel_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDlevel_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDlevel_95953Objects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDlevel_95953Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDlevel_95953Objects2[k] = gdjs.Main_95menuCode.GDlevel_95953Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDlevel_95953Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDlevel_95952Objects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDlevel_95952Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDlevel_95952Objects2[k] = gdjs.Main_95menuCode.GDlevel_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDlevel_95952Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDlevel_95954Objects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDlevel_95954Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDlevel_95954Objects2[k] = gdjs.Main_95menuCode.GDlevel_95954Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDlevel_95954Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDback2Objects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDback2Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDback2Objects2[k] = gdjs.Main_95menuCode.GDback2Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDback2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2[k] = gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDback3Objects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDback3Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDback3Objects2[k] = gdjs.Main_95menuCode.GDback3Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDback3Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDauthorsObjects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDauthorsObjects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDauthorsObjects2[k] = gdjs.Main_95menuCode.GDauthorsObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDauthorsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDback4Objects2.length;i<l;++i) {
    if ( !(gdjs.Main_95menuCode.GDback4Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDback4Objects2[k] = gdjs.Main_95menuCode.GDback4Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDback4Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_95menuCode.GDauthorsObjects2 */
/* Reuse gdjs.Main_95menuCode.GDbackObjects2 */
/* Reuse gdjs.Main_95menuCode.GDback2Objects2 */
/* Reuse gdjs.Main_95menuCode.GDback3Objects2 */
/* Reuse gdjs.Main_95menuCode.GDback4Objects2 */
/* Reuse gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2 */
/* Reuse gdjs.Main_95menuCode.GDlevel_95951Objects2 */
/* Reuse gdjs.Main_95menuCode.GDlevel_95952Objects2 */
/* Reuse gdjs.Main_95menuCode.GDlevel_95953Objects2 */
/* Reuse gdjs.Main_95menuCode.GDlevel_95954Objects2 */
/* Reuse gdjs.Main_95menuCode.GDplayObjects2 */
/* Reuse gdjs.Main_95menuCode.GDquitObjects2 */
/* Reuse gdjs.Main_95menuCode.GDsettingsObjects2 */
{for(var i = 0, len = gdjs.Main_95menuCode.GDplayObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDplayObjects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDquitObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDquitObjects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDsettingsObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDsettingsObjects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDbackObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDbackObjects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDlevel_95951Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDlevel_95951Objects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDlevel_95953Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDlevel_95953Objects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDlevel_95952Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDlevel_95952Objects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDlevel_95954Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDlevel_95954Objects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDback2Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDback2Objects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDback3Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDback3Objects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDauthorsObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDauthorsObjects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDback4Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDback4Objects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("authors"), gdjs.Main_95menuCode.GDauthorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.Main_95menuCode.GDbackObjects2);
gdjs.copyArray(runtimeScene.getObjects("back2"), gdjs.Main_95menuCode.GDback2Objects2);
gdjs.copyArray(runtimeScene.getObjects("back3"), gdjs.Main_95menuCode.GDback3Objects2);
gdjs.copyArray(runtimeScene.getObjects("back4"), gdjs.Main_95menuCode.GDback4Objects2);
gdjs.copyArray(runtimeScene.getObjects("controllers_info"), gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2);
gdjs.copyArray(runtimeScene.getObjects("level_1"), gdjs.Main_95menuCode.GDlevel_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("level_2"), gdjs.Main_95menuCode.GDlevel_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("level_3"), gdjs.Main_95menuCode.GDlevel_95953Objects2);
gdjs.copyArray(runtimeScene.getObjects("level_4"), gdjs.Main_95menuCode.GDlevel_95954Objects2);
gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.Main_95menuCode.GDplayObjects2);
gdjs.copyArray(runtimeScene.getObjects("quit"), gdjs.Main_95menuCode.GDquitObjects2);
gdjs.copyArray(runtimeScene.getObjects("settings"), gdjs.Main_95menuCode.GDsettingsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDplayObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDplayObjects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDplayObjects2[k] = gdjs.Main_95menuCode.GDplayObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDplayObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDquitObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDquitObjects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDquitObjects2[k] = gdjs.Main_95menuCode.GDquitObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDquitObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDsettingsObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDsettingsObjects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDsettingsObjects2[k] = gdjs.Main_95menuCode.GDsettingsObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDsettingsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDbackObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDbackObjects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDbackObjects2[k] = gdjs.Main_95menuCode.GDbackObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDbackObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDlevel_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDlevel_95951Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDlevel_95951Objects2[k] = gdjs.Main_95menuCode.GDlevel_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDlevel_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDlevel_95953Objects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDlevel_95953Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDlevel_95953Objects2[k] = gdjs.Main_95menuCode.GDlevel_95953Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDlevel_95953Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDlevel_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDlevel_95952Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDlevel_95952Objects2[k] = gdjs.Main_95menuCode.GDlevel_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDlevel_95952Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDlevel_95954Objects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDlevel_95954Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDlevel_95954Objects2[k] = gdjs.Main_95menuCode.GDlevel_95954Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDlevel_95954Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDback2Objects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDback2Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDback2Objects2[k] = gdjs.Main_95menuCode.GDback2Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDback2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2[k] = gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDback3Objects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDback3Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDback3Objects2[k] = gdjs.Main_95menuCode.GDback3Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDback3Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDauthorsObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDauthorsObjects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDauthorsObjects2[k] = gdjs.Main_95menuCode.GDauthorsObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDauthorsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDback4Objects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDback4Objects2[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDback4Objects2[k] = gdjs.Main_95menuCode.GDback4Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDback4Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_95menuCode.GDauthorsObjects2 */
/* Reuse gdjs.Main_95menuCode.GDbackObjects2 */
/* Reuse gdjs.Main_95menuCode.GDback2Objects2 */
/* Reuse gdjs.Main_95menuCode.GDback3Objects2 */
/* Reuse gdjs.Main_95menuCode.GDback4Objects2 */
/* Reuse gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2 */
/* Reuse gdjs.Main_95menuCode.GDlevel_95951Objects2 */
/* Reuse gdjs.Main_95menuCode.GDlevel_95952Objects2 */
/* Reuse gdjs.Main_95menuCode.GDlevel_95953Objects2 */
/* Reuse gdjs.Main_95menuCode.GDlevel_95954Objects2 */
/* Reuse gdjs.Main_95menuCode.GDplayObjects2 */
/* Reuse gdjs.Main_95menuCode.GDquitObjects2 */
/* Reuse gdjs.Main_95menuCode.GDsettingsObjects2 */
{for(var i = 0, len = gdjs.Main_95menuCode.GDplayObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDplayObjects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDquitObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDquitObjects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDsettingsObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDsettingsObjects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDbackObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDbackObjects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDlevel_95951Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDlevel_95951Objects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDlevel_95953Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDlevel_95953Objects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDlevel_95952Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDlevel_95952Objects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDlevel_95954Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDlevel_95954Objects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDback2Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDback2Objects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDback3Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDback3Objects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDauthorsObjects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDauthorsObjects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Main_95menuCode.GDback4Objects2.length ;i < len;++i) {
    gdjs.Main_95menuCode.GDback4Objects2[i].getBehavior("Effect").enableEffect("Effect", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.Main_95menuCode.GDbackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDbackObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDbackObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDbackObjects2[k] = gdjs.Main_95menuCode.GDbackObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDbackObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("marker_menu"), gdjs.Main_95menuCode.GDmarker_9595menuObjects2);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.Main_95menuCode.GDmarker_9595menuObjects2.length === 0 ) ? 0 :gdjs.Main_95menuCode.GDmarker_9595menuObjects2[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 2);
}{gdjs.evtTools.storage.writeStringInJSONFile("Settings", "Settings", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(1)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("back3"), gdjs.Main_95menuCode.GDback3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDback3Objects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDback3Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDback3Objects2[k] = gdjs.Main_95menuCode.GDback3Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDback3Objects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("marker_menu"), gdjs.Main_95menuCode.GDmarker_9595menuObjects2);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.Main_95menuCode.GDmarker_9595menuObjects2.length === 0 ) ? 0 :gdjs.Main_95menuCode.GDmarker_9595menuObjects2[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("back4"), gdjs.Main_95menuCode.GDback4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDback4Objects1.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDback4Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDback4Objects1[k] = gdjs.Main_95menuCode.GDback4Objects1[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDback4Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("marker_menu"), gdjs.Main_95menuCode.GDmarker_9595menuObjects1);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.Main_95menuCode.GDmarker_9595menuObjects1.length === 0 ) ? 0 :gdjs.Main_95menuCode.GDmarker_9595menuObjects1[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 2);
}}

}


};gdjs.Main_95menuCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.Main_95menuCode.GDplayObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDplayObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDplayObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDplayObjects2[k] = gdjs.Main_95menuCode.GDplayObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDplayObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("marker_level_select"), gdjs.Main_95menuCode.GDmarker_9595level_9595selectObjects2);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "level_selector", (( gdjs.Main_95menuCode.GDmarker_9595level_9595selectObjects2.length === 0 ) ? 0 :gdjs.Main_95menuCode.GDmarker_9595level_9595selectObjects2[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("level_1"), gdjs.Main_95menuCode.GDlevel_95951Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDlevel_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDlevel_95951Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDlevel_95951Objects2[k] = gdjs.Main_95menuCode.GDlevel_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDlevel_95951Objects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl_1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("level_2"), gdjs.Main_95menuCode.GDlevel_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDlevel_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDlevel_95952Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDlevel_95952Objects2[k] = gdjs.Main_95menuCode.GDlevel_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDlevel_95952Objects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl_2", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("level_3"), gdjs.Main_95menuCode.GDlevel_95953Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDlevel_95953Objects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDlevel_95953Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDlevel_95953Objects2[k] = gdjs.Main_95menuCode.GDlevel_95953Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDlevel_95953Objects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl_3", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("level_4"), gdjs.Main_95menuCode.GDlevel_95954Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDlevel_95954Objects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDlevel_95954Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDlevel_95954Objects2[k] = gdjs.Main_95menuCode.GDlevel_95954Objects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDlevel_95954Objects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl_4", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("back2"), gdjs.Main_95menuCode.GDback2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDback2Objects1.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDback2Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDback2Objects1[k] = gdjs.Main_95menuCode.GDback2Objects1[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDback2Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("marker_menu"), gdjs.Main_95menuCode.GDmarker_9595menuObjects1);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.Main_95menuCode.GDmarker_9595menuObjects1.length === 0 ) ? 0 :gdjs.Main_95menuCode.GDmarker_9595menuObjects1[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 2);
}}

}


};gdjs.Main_95menuCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sound_slider"), gdjs.Main_95menuCode.GDsound_9595sliderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDsound_9595sliderObjects2.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDsound_9595sliderObjects2[i].IsBeingDragged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDsound_9595sliderObjects2[k] = gdjs.Main_95menuCode.GDsound_9595sliderObjects2[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDsound_9595sliderObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_95menuCode.GDsound_9595sliderObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(1).getChild("Sound").setNumber((( gdjs.Main_95menuCode.GDsound_9595sliderObjects2.length === 0 ) ? 0 :gdjs.Main_95menuCode.GDsound_9595sliderObjects2[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_slider"), gdjs.Main_95menuCode.GDmusic_9595sliderObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95menuCode.GDmusic_9595sliderObjects1.length;i<l;++i) {
    if ( gdjs.Main_95menuCode.GDmusic_9595sliderObjects1[i].IsBeingDragged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95menuCode.GDmusic_9595sliderObjects1[k] = gdjs.Main_95menuCode.GDmusic_9595sliderObjects1[i];
        ++k;
    }
}
gdjs.Main_95menuCode.GDmusic_9595sliderObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_95menuCode.GDmusic_9595sliderObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(1).getChild("Music").setNumber((( gdjs.Main_95menuCode.GDmusic_9595sliderObjects1.length === 0 ) ? 0 :gdjs.Main_95menuCode.GDmusic_9595sliderObjects1[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}{gdjs.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("Music")));
}}

}


};gdjs.Main_95menuCode.eventsList3 = function(runtimeScene) {

{


gdjs.Main_95menuCode.eventsList0(runtimeScene);
}


{


gdjs.Main_95menuCode.eventsList1(runtimeScene);
}


{


gdjs.Main_95menuCode.eventsList2(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Main_95menuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_95menuCode.GDtitleObjects1.length = 0;
gdjs.Main_95menuCode.GDtitleObjects2.length = 0;
gdjs.Main_95menuCode.GDtitleObjects3.length = 0;
gdjs.Main_95menuCode.GDplayObjects1.length = 0;
gdjs.Main_95menuCode.GDplayObjects2.length = 0;
gdjs.Main_95menuCode.GDplayObjects3.length = 0;
gdjs.Main_95menuCode.GDquitObjects1.length = 0;
gdjs.Main_95menuCode.GDquitObjects2.length = 0;
gdjs.Main_95menuCode.GDquitObjects3.length = 0;
gdjs.Main_95menuCode.GDsettingsObjects1.length = 0;
gdjs.Main_95menuCode.GDsettingsObjects2.length = 0;
gdjs.Main_95menuCode.GDsettingsObjects3.length = 0;
gdjs.Main_95menuCode.GDsoundObjects1.length = 0;
gdjs.Main_95menuCode.GDsoundObjects2.length = 0;
gdjs.Main_95menuCode.GDsoundObjects3.length = 0;
gdjs.Main_95menuCode.GDsound_9595sliderObjects1.length = 0;
gdjs.Main_95menuCode.GDsound_9595sliderObjects2.length = 0;
gdjs.Main_95menuCode.GDsound_9595sliderObjects3.length = 0;
gdjs.Main_95menuCode.GDmusicObjects1.length = 0;
gdjs.Main_95menuCode.GDmusicObjects2.length = 0;
gdjs.Main_95menuCode.GDmusicObjects3.length = 0;
gdjs.Main_95menuCode.GDmusic_9595sliderObjects1.length = 0;
gdjs.Main_95menuCode.GDmusic_9595sliderObjects2.length = 0;
gdjs.Main_95menuCode.GDmusic_9595sliderObjects3.length = 0;
gdjs.Main_95menuCode.GDbackObjects1.length = 0;
gdjs.Main_95menuCode.GDbackObjects2.length = 0;
gdjs.Main_95menuCode.GDbackObjects3.length = 0;
gdjs.Main_95menuCode.GDmarker_9595menuObjects1.length = 0;
gdjs.Main_95menuCode.GDmarker_9595menuObjects2.length = 0;
gdjs.Main_95menuCode.GDmarker_9595menuObjects3.length = 0;
gdjs.Main_95menuCode.GDmarker_9595settingsObjects1.length = 0;
gdjs.Main_95menuCode.GDmarker_9595settingsObjects2.length = 0;
gdjs.Main_95menuCode.GDmarker_9595settingsObjects3.length = 0;
gdjs.Main_95menuCode.GDmarker_9595level_9595selectObjects1.length = 0;
gdjs.Main_95menuCode.GDmarker_9595level_9595selectObjects2.length = 0;
gdjs.Main_95menuCode.GDmarker_9595level_9595selectObjects3.length = 0;
gdjs.Main_95menuCode.GDlevel_95951Objects1.length = 0;
gdjs.Main_95menuCode.GDlevel_95951Objects2.length = 0;
gdjs.Main_95menuCode.GDlevel_95951Objects3.length = 0;
gdjs.Main_95menuCode.GDlevel_95952Objects1.length = 0;
gdjs.Main_95menuCode.GDlevel_95952Objects2.length = 0;
gdjs.Main_95menuCode.GDlevel_95952Objects3.length = 0;
gdjs.Main_95menuCode.GDlevel_95953Objects1.length = 0;
gdjs.Main_95menuCode.GDlevel_95953Objects2.length = 0;
gdjs.Main_95menuCode.GDlevel_95953Objects3.length = 0;
gdjs.Main_95menuCode.GDlevel_95954Objects1.length = 0;
gdjs.Main_95menuCode.GDlevel_95954Objects2.length = 0;
gdjs.Main_95menuCode.GDlevel_95954Objects3.length = 0;
gdjs.Main_95menuCode.GDback2Objects1.length = 0;
gdjs.Main_95menuCode.GDback2Objects2.length = 0;
gdjs.Main_95menuCode.GDback2Objects3.length = 0;
gdjs.Main_95menuCode.GDcontrollers_9595infoObjects1.length = 0;
gdjs.Main_95menuCode.GDcontrollers_9595infoObjects2.length = 0;
gdjs.Main_95menuCode.GDcontrollers_9595infoObjects3.length = 0;
gdjs.Main_95menuCode.GDmarker_9595controllerObjects1.length = 0;
gdjs.Main_95menuCode.GDmarker_9595controllerObjects2.length = 0;
gdjs.Main_95menuCode.GDmarker_9595controllerObjects3.length = 0;
gdjs.Main_95menuCode.GDArrowKeyObjects1.length = 0;
gdjs.Main_95menuCode.GDArrowKeyObjects2.length = 0;
gdjs.Main_95menuCode.GDArrowKeyObjects3.length = 0;
gdjs.Main_95menuCode.GDArrowKey2Objects1.length = 0;
gdjs.Main_95menuCode.GDArrowKey2Objects2.length = 0;
gdjs.Main_95menuCode.GDArrowKey2Objects3.length = 0;
gdjs.Main_95menuCode.GDLetterKeyObjects1.length = 0;
gdjs.Main_95menuCode.GDLetterKeyObjects2.length = 0;
gdjs.Main_95menuCode.GDLetterKeyObjects3.length = 0;
gdjs.Main_95menuCode.GDSpaceKeyObjects1.length = 0;
gdjs.Main_95menuCode.GDSpaceKeyObjects2.length = 0;
gdjs.Main_95menuCode.GDSpaceKeyObjects3.length = 0;
gdjs.Main_95menuCode.GDcontrollers_9595moveObjects1.length = 0;
gdjs.Main_95menuCode.GDcontrollers_9595moveObjects2.length = 0;
gdjs.Main_95menuCode.GDcontrollers_9595moveObjects3.length = 0;
gdjs.Main_95menuCode.GDcontrollers_9595jumpObjects1.length = 0;
gdjs.Main_95menuCode.GDcontrollers_9595jumpObjects2.length = 0;
gdjs.Main_95menuCode.GDcontrollers_9595jumpObjects3.length = 0;
gdjs.Main_95menuCode.GDcontrollers_9595attackObjects1.length = 0;
gdjs.Main_95menuCode.GDcontrollers_9595attackObjects2.length = 0;
gdjs.Main_95menuCode.GDcontrollers_9595attackObjects3.length = 0;
gdjs.Main_95menuCode.GDback3Objects1.length = 0;
gdjs.Main_95menuCode.GDback3Objects2.length = 0;
gdjs.Main_95menuCode.GDback3Objects3.length = 0;
gdjs.Main_95menuCode.GDauthorsObjects1.length = 0;
gdjs.Main_95menuCode.GDauthorsObjects2.length = 0;
gdjs.Main_95menuCode.GDauthorsObjects3.length = 0;
gdjs.Main_95menuCode.GDmarker_9595autorsObjects1.length = 0;
gdjs.Main_95menuCode.GDmarker_9595autorsObjects2.length = 0;
gdjs.Main_95menuCode.GDmarker_9595autorsObjects3.length = 0;
gdjs.Main_95menuCode.GDauthors_9595textObjects1.length = 0;
gdjs.Main_95menuCode.GDauthors_9595textObjects2.length = 0;
gdjs.Main_95menuCode.GDauthors_9595textObjects3.length = 0;
gdjs.Main_95menuCode.GDback4Objects1.length = 0;
gdjs.Main_95menuCode.GDback4Objects2.length = 0;
gdjs.Main_95menuCode.GDback4Objects3.length = 0;
gdjs.Main_95menuCode.GDplayer_9595hudObjects1.length = 0;
gdjs.Main_95menuCode.GDplayer_9595hudObjects2.length = 0;
gdjs.Main_95menuCode.GDplayer_9595hudObjects3.length = 0;
gdjs.Main_95menuCode.GDlife_9595hudObjects1.length = 0;
gdjs.Main_95menuCode.GDlife_9595hudObjects2.length = 0;
gdjs.Main_95menuCode.GDlife_9595hudObjects3.length = 0;
gdjs.Main_95menuCode.GDEnergyBarObjects1.length = 0;
gdjs.Main_95menuCode.GDEnergyBarObjects2.length = 0;
gdjs.Main_95menuCode.GDEnergyBarObjects3.length = 0;
gdjs.Main_95menuCode.GDPortraitBackroundObjects1.length = 0;
gdjs.Main_95menuCode.GDPortraitBackroundObjects2.length = 0;
gdjs.Main_95menuCode.GDPortraitBackroundObjects3.length = 0;
gdjs.Main_95menuCode.GDbackgroundObjects1.length = 0;
gdjs.Main_95menuCode.GDbackgroundObjects2.length = 0;
gdjs.Main_95menuCode.GDbackgroundObjects3.length = 0;
gdjs.Main_95menuCode.GDSpikesObjects1.length = 0;
gdjs.Main_95menuCode.GDSpikesObjects2.length = 0;
gdjs.Main_95menuCode.GDSpikesObjects3.length = 0;
gdjs.Main_95menuCode.GDplayerObjects1.length = 0;
gdjs.Main_95menuCode.GDplayerObjects2.length = 0;
gdjs.Main_95menuCode.GDplayerObjects3.length = 0;
gdjs.Main_95menuCode.GDkeyObjects1.length = 0;
gdjs.Main_95menuCode.GDkeyObjects2.length = 0;
gdjs.Main_95menuCode.GDkeyObjects3.length = 0;
gdjs.Main_95menuCode.GDcollisionObjects1.length = 0;
gdjs.Main_95menuCode.GDcollisionObjects2.length = 0;
gdjs.Main_95menuCode.GDcollisionObjects3.length = 0;
gdjs.Main_95menuCode.GDCollisionCheckObjects1.length = 0;
gdjs.Main_95menuCode.GDCollisionCheckObjects2.length = 0;
gdjs.Main_95menuCode.GDCollisionCheckObjects3.length = 0;
gdjs.Main_95menuCode.GDratObjects1.length = 0;
gdjs.Main_95menuCode.GDratObjects2.length = 0;
gdjs.Main_95menuCode.GDratObjects3.length = 0;
gdjs.Main_95menuCode.GDrat_9595attackObjects1.length = 0;
gdjs.Main_95menuCode.GDrat_9595attackObjects2.length = 0;
gdjs.Main_95menuCode.GDrat_9595attackObjects3.length = 0;
gdjs.Main_95menuCode.GDMenu_9595backgroundObjects1.length = 0;
gdjs.Main_95menuCode.GDMenu_9595backgroundObjects2.length = 0;
gdjs.Main_95menuCode.GDMenu_9595backgroundObjects3.length = 0;

gdjs.Main_95menuCode.eventsList3(runtimeScene);

return;

}

gdjs['Main_95menuCode'] = gdjs.Main_95menuCode;
