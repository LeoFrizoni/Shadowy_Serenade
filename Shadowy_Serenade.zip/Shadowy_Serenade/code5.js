gdjs.death_95sceneCode = {};
gdjs.death_95sceneCode.localVariables = [];
gdjs.death_95sceneCode.GDdeath_9595imgObjects1= [];
gdjs.death_95sceneCode.GDdeath_9595imgObjects2= [];
gdjs.death_95sceneCode.GDPlayObjects1= [];
gdjs.death_95sceneCode.GDPlayObjects2= [];
gdjs.death_95sceneCode.GDplayer_9595hudObjects1= [];
gdjs.death_95sceneCode.GDplayer_9595hudObjects2= [];
gdjs.death_95sceneCode.GDlife_9595hudObjects1= [];
gdjs.death_95sceneCode.GDlife_9595hudObjects2= [];
gdjs.death_95sceneCode.GDEnergyBarObjects1= [];
gdjs.death_95sceneCode.GDEnergyBarObjects2= [];
gdjs.death_95sceneCode.GDPortraitBackroundObjects1= [];
gdjs.death_95sceneCode.GDPortraitBackroundObjects2= [];
gdjs.death_95sceneCode.GDbackgroundObjects1= [];
gdjs.death_95sceneCode.GDbackgroundObjects2= [];
gdjs.death_95sceneCode.GDSpikesObjects1= [];
gdjs.death_95sceneCode.GDSpikesObjects2= [];
gdjs.death_95sceneCode.GDplayerObjects1= [];
gdjs.death_95sceneCode.GDplayerObjects2= [];
gdjs.death_95sceneCode.GDkeyObjects1= [];
gdjs.death_95sceneCode.GDkeyObjects2= [];
gdjs.death_95sceneCode.GDcollisionObjects1= [];
gdjs.death_95sceneCode.GDcollisionObjects2= [];
gdjs.death_95sceneCode.GDCollisionCheckObjects1= [];
gdjs.death_95sceneCode.GDCollisionCheckObjects2= [];
gdjs.death_95sceneCode.GDratObjects1= [];
gdjs.death_95sceneCode.GDratObjects2= [];
gdjs.death_95sceneCode.GDrat_9595attackObjects1= [];
gdjs.death_95sceneCode.GDrat_9595attackObjects2= [];
gdjs.death_95sceneCode.GDMenu_9595backgroundObjects1= [];
gdjs.death_95sceneCode.GDMenu_9595backgroundObjects2= [];


gdjs.death_95sceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.death_95sceneCode.GDPlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.death_95sceneCode.GDPlayObjects1.length;i<l;++i) {
    if ( gdjs.death_95sceneCode.GDPlayObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.death_95sceneCode.GDPlayObjects1[k] = gdjs.death_95sceneCode.GDPlayObjects1[i];
        ++k;
    }
}
gdjs.death_95sceneCode.GDPlayObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main_menu", false);
}}

}


};

gdjs.death_95sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.death_95sceneCode.GDdeath_9595imgObjects1.length = 0;
gdjs.death_95sceneCode.GDdeath_9595imgObjects2.length = 0;
gdjs.death_95sceneCode.GDPlayObjects1.length = 0;
gdjs.death_95sceneCode.GDPlayObjects2.length = 0;
gdjs.death_95sceneCode.GDplayer_9595hudObjects1.length = 0;
gdjs.death_95sceneCode.GDplayer_9595hudObjects2.length = 0;
gdjs.death_95sceneCode.GDlife_9595hudObjects1.length = 0;
gdjs.death_95sceneCode.GDlife_9595hudObjects2.length = 0;
gdjs.death_95sceneCode.GDEnergyBarObjects1.length = 0;
gdjs.death_95sceneCode.GDEnergyBarObjects2.length = 0;
gdjs.death_95sceneCode.GDPortraitBackroundObjects1.length = 0;
gdjs.death_95sceneCode.GDPortraitBackroundObjects2.length = 0;
gdjs.death_95sceneCode.GDbackgroundObjects1.length = 0;
gdjs.death_95sceneCode.GDbackgroundObjects2.length = 0;
gdjs.death_95sceneCode.GDSpikesObjects1.length = 0;
gdjs.death_95sceneCode.GDSpikesObjects2.length = 0;
gdjs.death_95sceneCode.GDplayerObjects1.length = 0;
gdjs.death_95sceneCode.GDplayerObjects2.length = 0;
gdjs.death_95sceneCode.GDkeyObjects1.length = 0;
gdjs.death_95sceneCode.GDkeyObjects2.length = 0;
gdjs.death_95sceneCode.GDcollisionObjects1.length = 0;
gdjs.death_95sceneCode.GDcollisionObjects2.length = 0;
gdjs.death_95sceneCode.GDCollisionCheckObjects1.length = 0;
gdjs.death_95sceneCode.GDCollisionCheckObjects2.length = 0;
gdjs.death_95sceneCode.GDratObjects1.length = 0;
gdjs.death_95sceneCode.GDratObjects2.length = 0;
gdjs.death_95sceneCode.GDrat_9595attackObjects1.length = 0;
gdjs.death_95sceneCode.GDrat_9595attackObjects2.length = 0;
gdjs.death_95sceneCode.GDMenu_9595backgroundObjects1.length = 0;
gdjs.death_95sceneCode.GDMenu_9595backgroundObjects2.length = 0;

gdjs.death_95sceneCode.eventsList0(runtimeScene);

return;

}

gdjs['death_95sceneCode'] = gdjs.death_95sceneCode;
