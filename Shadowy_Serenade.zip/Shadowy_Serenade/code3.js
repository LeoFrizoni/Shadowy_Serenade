gdjs.lvl_953Code = {};
gdjs.lvl_953Code.localVariables = [];
gdjs.lvl_953Code.GDSpikesObjects2_1final = [];

gdjs.lvl_953Code.GDplayerObjects1_1final = [];

gdjs.lvl_953Code.GDplayerObjects2_1final = [];

gdjs.lvl_953Code.GDrat_9595attackObjects2_1final = [];

gdjs.lvl_953Code.forEachIndex3 = 0;

gdjs.lvl_953Code.forEachObjects3 = [];

gdjs.lvl_953Code.forEachTemporary3 = null;

gdjs.lvl_953Code.forEachTotalCount3 = 0;

gdjs.lvl_953Code.GDlvl_95953Objects1= [];
gdjs.lvl_953Code.GDlvl_95953Objects2= [];
gdjs.lvl_953Code.GDlvl_95953Objects3= [];
gdjs.lvl_953Code.GDlvl_95953Objects4= [];
gdjs.lvl_953Code.GDlvl_95953Objects5= [];
gdjs.lvl_953Code.GDlvl_95953_9595textObjects1= [];
gdjs.lvl_953Code.GDlvl_95953_9595textObjects2= [];
gdjs.lvl_953Code.GDlvl_95953_9595textObjects3= [];
gdjs.lvl_953Code.GDlvl_95953_9595textObjects4= [];
gdjs.lvl_953Code.GDlvl_95953_9595textObjects5= [];
gdjs.lvl_953Code.GDplayer_9595hudObjects1= [];
gdjs.lvl_953Code.GDplayer_9595hudObjects2= [];
gdjs.lvl_953Code.GDplayer_9595hudObjects3= [];
gdjs.lvl_953Code.GDplayer_9595hudObjects4= [];
gdjs.lvl_953Code.GDplayer_9595hudObjects5= [];
gdjs.lvl_953Code.GDlife_9595hudObjects1= [];
gdjs.lvl_953Code.GDlife_9595hudObjects2= [];
gdjs.lvl_953Code.GDlife_9595hudObjects3= [];
gdjs.lvl_953Code.GDlife_9595hudObjects4= [];
gdjs.lvl_953Code.GDlife_9595hudObjects5= [];
gdjs.lvl_953Code.GDEnergyBarObjects1= [];
gdjs.lvl_953Code.GDEnergyBarObjects2= [];
gdjs.lvl_953Code.GDEnergyBarObjects3= [];
gdjs.lvl_953Code.GDEnergyBarObjects4= [];
gdjs.lvl_953Code.GDEnergyBarObjects5= [];
gdjs.lvl_953Code.GDPortraitBackroundObjects1= [];
gdjs.lvl_953Code.GDPortraitBackroundObjects2= [];
gdjs.lvl_953Code.GDPortraitBackroundObjects3= [];
gdjs.lvl_953Code.GDPortraitBackroundObjects4= [];
gdjs.lvl_953Code.GDPortraitBackroundObjects5= [];
gdjs.lvl_953Code.GDbackgroundObjects1= [];
gdjs.lvl_953Code.GDbackgroundObjects2= [];
gdjs.lvl_953Code.GDbackgroundObjects3= [];
gdjs.lvl_953Code.GDbackgroundObjects4= [];
gdjs.lvl_953Code.GDbackgroundObjects5= [];
gdjs.lvl_953Code.GDSpikesObjects1= [];
gdjs.lvl_953Code.GDSpikesObjects2= [];
gdjs.lvl_953Code.GDSpikesObjects3= [];
gdjs.lvl_953Code.GDSpikesObjects4= [];
gdjs.lvl_953Code.GDSpikesObjects5= [];
gdjs.lvl_953Code.GDplayerObjects1= [];
gdjs.lvl_953Code.GDplayerObjects2= [];
gdjs.lvl_953Code.GDplayerObjects3= [];
gdjs.lvl_953Code.GDplayerObjects4= [];
gdjs.lvl_953Code.GDplayerObjects5= [];
gdjs.lvl_953Code.GDkeyObjects1= [];
gdjs.lvl_953Code.GDkeyObjects2= [];
gdjs.lvl_953Code.GDkeyObjects3= [];
gdjs.lvl_953Code.GDkeyObjects4= [];
gdjs.lvl_953Code.GDkeyObjects5= [];
gdjs.lvl_953Code.GDcollisionObjects1= [];
gdjs.lvl_953Code.GDcollisionObjects2= [];
gdjs.lvl_953Code.GDcollisionObjects3= [];
gdjs.lvl_953Code.GDcollisionObjects4= [];
gdjs.lvl_953Code.GDcollisionObjects5= [];
gdjs.lvl_953Code.GDCollisionCheckObjects1= [];
gdjs.lvl_953Code.GDCollisionCheckObjects2= [];
gdjs.lvl_953Code.GDCollisionCheckObjects3= [];
gdjs.lvl_953Code.GDCollisionCheckObjects4= [];
gdjs.lvl_953Code.GDCollisionCheckObjects5= [];
gdjs.lvl_953Code.GDratObjects1= [];
gdjs.lvl_953Code.GDratObjects2= [];
gdjs.lvl_953Code.GDratObjects3= [];
gdjs.lvl_953Code.GDratObjects4= [];
gdjs.lvl_953Code.GDratObjects5= [];
gdjs.lvl_953Code.GDrat_9595attackObjects1= [];
gdjs.lvl_953Code.GDrat_9595attackObjects2= [];
gdjs.lvl_953Code.GDrat_9595attackObjects3= [];
gdjs.lvl_953Code.GDrat_9595attackObjects4= [];
gdjs.lvl_953Code.GDrat_9595attackObjects5= [];
gdjs.lvl_953Code.GDMenu_9595backgroundObjects1= [];
gdjs.lvl_953Code.GDMenu_9595backgroundObjects2= [];
gdjs.lvl_953Code.GDMenu_9595backgroundObjects3= [];
gdjs.lvl_953Code.GDMenu_9595backgroundObjects4= [];
gdjs.lvl_953Code.GDMenu_9595backgroundObjects5= [];


gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.lvl_953Code.GDplayerObjects3});
gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDrat_95959595attackObjects3Objects = Hashtable.newFrom({"rat_attack": gdjs.lvl_953Code.GDrat_9595attackObjects3});
gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.lvl_953Code.GDplayerObjects3});
gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDSpikesObjects3Objects = Hashtable.newFrom({"Spikes": gdjs.lvl_953Code.GDSpikesObjects3});
gdjs.lvl_953Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects3[i].getBehavior("Flippable").flipX(true);
}
}}

}


};gdjs.lvl_953Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects3[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.lvl_953Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.lvl_953Code.GDplayerObjects2, gdjs.lvl_953Code.GDplayerObjects3);

{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects3[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
{ //Subevents
gdjs.lvl_953Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.lvl_953Code.GDplayerObjects2, gdjs.lvl_953Code.GDplayerObjects3);

{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects3[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
{ //Subevents
gdjs.lvl_953Code.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


};gdjs.lvl_953Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.lvl_953Code.GDplayerObjects2, gdjs.lvl_953Code.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects3[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects3[k] = gdjs.lvl_953Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects3[i].getBehavior("Animation").setAnimationName("run");
}
}}

}


{

/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("idle");
}
}}

}


};gdjs.lvl_953Code.eventsList4 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.lvl_953Code.GDplayerObjects1, gdjs.lvl_953Code.GDplayerObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getVariableNumber(gdjs.lvl_953Code.GDplayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl_953Code.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.lvl_953Code.GDplayerObjects1, gdjs.lvl_953Code.GDplayerObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl_953Code.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.lvl_953Code.GDplayerObjects1, gdjs.lvl_953Code.GDplayerObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("jump");
}
}}

}


{

gdjs.copyArray(gdjs.lvl_953Code.GDplayerObjects1, gdjs.lvl_953Code.GDplayerObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("fall");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects1 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects1[i].getBehavior("Animation").setAnimationName("attack");
}
}}

}


};gdjs.lvl_953Code.eventsList5 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("Animation").getAnimationName() == "attack" ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("idle");
}
}}

}


{



}


{

gdjs.lvl_953Code.GDSpikesObjects2.length = 0;

gdjs.lvl_953Code.GDplayerObjects2.length = 0;

gdjs.lvl_953Code.GDrat_9595attackObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.lvl_953Code.GDSpikesObjects2_1final.length = 0;
gdjs.lvl_953Code.GDplayerObjects2_1final.length = 0;
gdjs.lvl_953Code.GDrat_9595attackObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("rat_attack"), gdjs.lvl_953Code.GDrat_9595attackObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDplayerObjects3Objects, gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDrat_95959595attackObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.lvl_953Code.GDplayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.lvl_953Code.GDplayerObjects2_1final.indexOf(gdjs.lvl_953Code.GDplayerObjects3[j]) === -1 )
            gdjs.lvl_953Code.GDplayerObjects2_1final.push(gdjs.lvl_953Code.GDplayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.lvl_953Code.GDrat_9595attackObjects3.length; j < jLen ; ++j) {
        if ( gdjs.lvl_953Code.GDrat_9595attackObjects2_1final.indexOf(gdjs.lvl_953Code.GDrat_9595attackObjects3[j]) === -1 )
            gdjs.lvl_953Code.GDrat_9595attackObjects2_1final.push(gdjs.lvl_953Code.GDrat_9595attackObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Spikes"), gdjs.lvl_953Code.GDSpikesObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDplayerObjects3Objects, gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDSpikesObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.lvl_953Code.GDSpikesObjects3.length; j < jLen ; ++j) {
        if ( gdjs.lvl_953Code.GDSpikesObjects2_1final.indexOf(gdjs.lvl_953Code.GDSpikesObjects3[j]) === -1 )
            gdjs.lvl_953Code.GDSpikesObjects2_1final.push(gdjs.lvl_953Code.GDSpikesObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.lvl_953Code.GDplayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.lvl_953Code.GDplayerObjects2_1final.indexOf(gdjs.lvl_953Code.GDplayerObjects3[j]) === -1 )
            gdjs.lvl_953Code.GDplayerObjects2_1final.push(gdjs.lvl_953Code.GDplayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.lvl_953Code.GDSpikesObjects2_1final, gdjs.lvl_953Code.GDSpikesObjects2);
gdjs.copyArray(gdjs.lvl_953Code.GDplayerObjects2_1final, gdjs.lvl_953Code.GDplayerObjects2);
gdjs.copyArray(gdjs.lvl_953Code.GDrat_9595attackObjects2_1final, gdjs.lvl_953Code.GDrat_9595attackObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14348316);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("get_hit");
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).sub(1);
}{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("Flash").Flash(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects1.length;i<l;++i) {
    if ( !(gdjs.lvl_953Code.GDplayerObjects1[i].getBehavior("Animation").getAnimationName() == "attack") ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects1[k] = gdjs.lvl_953Code.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl_953Code.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.lvl_953Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getVariableNumber(gdjs.lvl_953Code.GDplayerObjects2[i].getVariables().getFromIndex(0)) == -(1) ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getVariableNumber(gdjs.lvl_953Code.GDplayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects1[i].getVariableNumber(gdjs.lvl_953Code.GDplayerObjects1[i].getVariables().getFromIndex(0)) != 0 ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects1[k] = gdjs.lvl_953Code.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.lvl_953Code.GDplayerObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.lvl_953Code.GDplayerObjects1, gdjs.lvl_953Code.GDplayerObjects2);

for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_1 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.lvl_953Code.GDplayerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.lvl_953Code.GDplayerObjects1_1final.indexOf(gdjs.lvl_953Code.GDplayerObjects2[j]) === -1 )
            gdjs.lvl_953Code.GDplayerObjects1_1final.push(gdjs.lvl_953Code.GDplayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.lvl_953Code.GDplayerObjects1, gdjs.lvl_953Code.GDplayerObjects2);

for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_1 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.lvl_953Code.GDplayerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.lvl_953Code.GDplayerObjects1_1final.indexOf(gdjs.lvl_953Code.GDplayerObjects2[j]) === -1 )
            gdjs.lvl_953Code.GDplayerObjects1_1final.push(gdjs.lvl_953Code.GDplayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.lvl_953Code.GDplayerObjects1_1final, gdjs.lvl_953Code.GDplayerObjects1);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects1 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects1[i].returnVariable(gdjs.lvl_953Code.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


};gdjs.lvl_953Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.lvl_953Code.GDplayerObjects1, gdjs.lvl_953Code.GDplayerObjects2);

{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].returnVariable(gdjs.lvl_953Code.GDplayerObjects2[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects1 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects1[i].returnVariable(gdjs.lvl_953Code.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(-(1));
}
}}

}


};gdjs.lvl_953Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl_953Code.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.lvl_953Code.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects2);
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").setMaxFallingSpeed(700, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("collision"), gdjs.lvl_953Code.GDcollisionObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects1[k] = gdjs.lvl_953Code.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDcollisionObjects1.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDcollisionObjects1[i].isCollidingWithPoint((( gdjs.lvl_953Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.lvl_953Code.GDplayerObjects1[0].getPointX("PointX")), (( gdjs.lvl_953Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.lvl_953Code.GDplayerObjects1[0].getPointY("PointX"))) ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDcollisionObjects1[k] = gdjs.lvl_953Code.GDcollisionObjects1[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDcollisionObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects1 */
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects1[i].getBehavior("PlatformerObject").setMaxFallingSpeed(100, false);
}
}{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects1[i].returnVariable(gdjs.lvl_953Code.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}
{ //Subevents
gdjs.lvl_953Code.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.lvl_953Code.GDplayerObjects2});
gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDratObjects2Objects = Hashtable.newFrom({"rat": gdjs.lvl_953Code.GDratObjects2});
gdjs.lvl_953Code.eventsList10 = function(runtimeScene) {

{

/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("rat"), gdjs.lvl_953Code.GDratObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDplayerObjects2Objects, gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDratObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */
/* Reuse gdjs.lvl_953Code.GDratObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects2[i].getBehavior("Animation").setAnimationName("get_hit");
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "New sound effect2", 1, false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("Sound")), 1);
}{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects2[i].returnVariable(gdjs.lvl_953Code.GDratObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}}

}


};gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDCollisionCheckObjects2Objects = Hashtable.newFrom({"CollisionCheck": gdjs.lvl_953Code.GDCollisionCheckObjects2});
gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDCollisionCheckObjects2Objects = Hashtable.newFrom({"CollisionCheck": gdjs.lvl_953Code.GDCollisionCheckObjects2});
gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDratObjects2Objects = Hashtable.newFrom({"rat": gdjs.lvl_953Code.GDratObjects2});
gdjs.lvl_953Code.eventsList11 = function(runtimeScene) {

{

/* Reuse gdjs.lvl_953Code.GDCollisionCheckObjects2 */
gdjs.copyArray(runtimeScene.getObjects("rat"), gdjs.lvl_953Code.GDratObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDCollisionCheckObjects2Objects, gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDratObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */
/* Reuse gdjs.lvl_953Code.GDratObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects2[i].getBehavior("Animation").setAnimationName("get_hit");
}
}{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects2[i].addPolarForce((( gdjs.lvl_953Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.lvl_953Code.GDplayerObjects2[0].getAngleToObject(gdjs.lvl_953Code.GDratObjects2[i])), 60, 1);
}
}{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects2[i].addForce(0, -(200), 1);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "New sound effect2", 1, false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("Sound")), 1);
}{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects2[i].returnVariable(gdjs.lvl_953Code.GDratObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}}

}


};gdjs.lvl_953Code.eventsList12 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl_953Code.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getBehavior("Animation").getAnimationName() == "attack" ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDplayerObjects2[i].getAnimationFrame() >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDplayerObjects2[k] = gdjs.lvl_953Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14370716);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDplayerObjects2 */
gdjs.lvl_953Code.GDCollisionCheckObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDCollisionCheckObjects2Objects, (( gdjs.lvl_953Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.lvl_953Code.GDplayerObjects2[0].getPointX("PointY")), (( gdjs.lvl_953Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.lvl_953Code.GDplayerObjects2[0].getPointY("PointY")), "");
}
{ //Subevents
gdjs.lvl_953Code.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("CollisionCheck"), gdjs.lvl_953Code.GDCollisionCheckObjects1);
{for(var i = 0, len = gdjs.lvl_953Code.GDCollisionCheckObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDCollisionCheckObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.lvl_953Code.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 6;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("life_hud"), gdjs.lvl_953Code.GDlife_9595hudObjects2);
{for(var i = 0, len = gdjs.lvl_953Code.GDlife_9595hudObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDlife_9595hudObjects2[i].getBehavior("Animation").setAnimationName("6");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("life_hud"), gdjs.lvl_953Code.GDlife_9595hudObjects2);
{for(var i = 0, len = gdjs.lvl_953Code.GDlife_9595hudObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDlife_9595hudObjects2[i].getBehavior("Animation").setAnimationName("5");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 4;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("life_hud"), gdjs.lvl_953Code.GDlife_9595hudObjects2);
{for(var i = 0, len = gdjs.lvl_953Code.GDlife_9595hudObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDlife_9595hudObjects2[i].getBehavior("Animation").setAnimationName("4");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("life_hud"), gdjs.lvl_953Code.GDlife_9595hudObjects2);
{for(var i = 0, len = gdjs.lvl_953Code.GDlife_9595hudObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDlife_9595hudObjects2[i].getBehavior("Animation").setAnimationName("3");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("life_hud"), gdjs.lvl_953Code.GDlife_9595hudObjects2);
{for(var i = 0, len = gdjs.lvl_953Code.GDlife_9595hudObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDlife_9595hudObjects2[i].getBehavior("Animation").setAnimationName("2");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("life_hud"), gdjs.lvl_953Code.GDlife_9595hudObjects1);
{for(var i = 0, len = gdjs.lvl_953Code.GDlife_9595hudObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDlife_9595hudObjects1[i].getBehavior("Animation").setAnimationName("1");
}
}}

}


};gdjs.lvl_953Code.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(6);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 0;
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl_953Code.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.lvl_953Code.eventsList15 = function(runtimeScene) {

};gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDCollisionCheckObjects2Objects = Hashtable.newFrom({"CollisionCheck": gdjs.lvl_953Code.GDCollisionCheckObjects2});
gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs.lvl_953Code.GDplayerObjects4});
gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs.lvl_953Code.GDplayerObjects4});
gdjs.lvl_953Code.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects4);
gdjs.copyArray(gdjs.lvl_953Code.GDratObjects3, gdjs.lvl_953Code.GDratObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects4.length;i<l;++i) {
    if ( !(gdjs.lvl_953Code.GDratObjects4[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects4[k] = gdjs.lvl_953Code.GDratObjects4[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDplayerObjects4Objects, (( gdjs.lvl_953Code.GDratObjects4.length === 0 ) ? 0 :gdjs.lvl_953Code.GDratObjects4[0].getCenterXInScene()), (( gdjs.lvl_953Code.GDratObjects4.length === 0 ) ? 0 :gdjs.lvl_953Code.GDratObjects4[0].getCenterYInScene()), 0, 70, gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDratObjects4 */
{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects4.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects4[i].getBehavior("Animation").setAnimationName("attack");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects4);
gdjs.copyArray(gdjs.lvl_953Code.GDratObjects3, gdjs.lvl_953Code.GDratObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects4.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDratObjects4[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects4[k] = gdjs.lvl_953Code.GDratObjects4[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDplayerObjects4Objects, (( gdjs.lvl_953Code.GDratObjects4.length === 0 ) ? 0 :gdjs.lvl_953Code.GDratObjects4[0].getCenterXInScene()), (( gdjs.lvl_953Code.GDratObjects4.length === 0 ) ? 0 :gdjs.lvl_953Code.GDratObjects4[0].getCenterYInScene()), 180, 70, gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDratObjects4 */
{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects4.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects4[i].getBehavior("Animation").setAnimationName("attack");
}
}}

}


};gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDrat_95959595attackObjects2Objects = Hashtable.newFrom({"rat_attack": gdjs.lvl_953Code.GDrat_9595attackObjects2});
gdjs.lvl_953Code.eventsList17 = function(runtimeScene) {

{

/* Reuse gdjs.lvl_953Code.GDratObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects2.length;i<l;++i) {
    if ( !(gdjs.lvl_953Code.GDratObjects2[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects2[k] = gdjs.lvl_953Code.GDratObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDrat_9595attackObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDrat_9595attackObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDrat_9595attackObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.lvl_953Code.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.lvl_953Code.GDratObjects1, gdjs.lvl_953Code.GDratObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDratObjects2[i].getAnimationFrame() >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects2[k] = gdjs.lvl_953Code.GDratObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14386908);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDratObjects2 */
gdjs.lvl_953Code.GDrat_9595attackObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDrat_95959595attackObjects2Objects, (( gdjs.lvl_953Code.GDratObjects2.length === 0 ) ? 0 :gdjs.lvl_953Code.GDratObjects2[0].getPointX("PointX")) - 45, (( gdjs.lvl_953Code.GDratObjects2.length === 0 ) ? 0 :gdjs.lvl_953Code.GDratObjects2[0].getPointY("PointY")), "");
}
{ //Subevents
gdjs.lvl_953Code.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.lvl_953Code.GDratObjects1, gdjs.lvl_953Code.GDratObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDratObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects2[k] = gdjs.lvl_953Code.GDratObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14388596);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDratObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects2[i].getBehavior("Animation").setAnimationName("idle");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("rat_attack"), gdjs.lvl_953Code.GDrat_9595attackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDrat_9595attackObjects1.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDrat_9595attackObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDrat_9595attackObjects1[k] = gdjs.lvl_953Code.GDrat_9595attackObjects1[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDrat_9595attackObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDrat_9595attackObjects1 */
{for(var i = 0, len = gdjs.lvl_953Code.GDrat_9595attackObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDrat_9595attackObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.lvl_953Code.eventsList19 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("rat"), gdjs.lvl_953Code.GDratObjects2);

for (gdjs.lvl_953Code.forEachIndex3 = 0;gdjs.lvl_953Code.forEachIndex3 < gdjs.lvl_953Code.GDratObjects2.length;++gdjs.lvl_953Code.forEachIndex3) {
gdjs.lvl_953Code.GDratObjects3.length = 0;


gdjs.lvl_953Code.forEachTemporary3 = gdjs.lvl_953Code.GDratObjects2[gdjs.lvl_953Code.forEachIndex3];
gdjs.lvl_953Code.GDratObjects3.push(gdjs.lvl_953Code.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects3.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDratObjects3[i].getBehavior("Animation").getAnimationName() == "get_hit" ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects3[k] = gdjs.lvl_953Code.GDratObjects3[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects3.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDratObjects3[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects3[k] = gdjs.lvl_953Code.GDratObjects3[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects3.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDratObjects3[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects3[k] = gdjs.lvl_953Code.GDratObjects3[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14381460);
}
}
}
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects3.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects3[i].getBehavior("Animation").setAnimationName("idle");
}
}{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects3.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects3[i].clearForces();
}
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("rat"), gdjs.lvl_953Code.GDratObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects2.length;i<l;++i) {
    if ( !(gdjs.lvl_953Code.GDratObjects2[i].getBehavior("Animation").getAnimationName() == "get_hit") ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects2[k] = gdjs.lvl_953Code.GDratObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CollisionCheck"), gdjs.lvl_953Code.GDCollisionCheckObjects2);
/* Reuse gdjs.lvl_953Code.GDratObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects2[i].separateFromObjectsList(gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDCollisionCheckObjects2Objects, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("rat"), gdjs.lvl_953Code.GDratObjects2);

for (gdjs.lvl_953Code.forEachIndex3 = 0;gdjs.lvl_953Code.forEachIndex3 < gdjs.lvl_953Code.GDratObjects2.length;++gdjs.lvl_953Code.forEachIndex3) {
gdjs.lvl_953Code.GDratObjects3.length = 0;


gdjs.lvl_953Code.forEachTemporary3 = gdjs.lvl_953Code.GDratObjects2[gdjs.lvl_953Code.forEachIndex3];
gdjs.lvl_953Code.GDratObjects3.push(gdjs.lvl_953Code.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects3.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDratObjects3[i].getBehavior("Animation").getAnimationName() == "idle" ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects3[k] = gdjs.lvl_953Code.GDratObjects3[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.lvl_953Code.eventsList16(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("rat"), gdjs.lvl_953Code.GDratObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects1.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDratObjects1[i].getBehavior("Animation").getAnimationName() == "attack" ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects1[k] = gdjs.lvl_953Code.GDratObjects1[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl_953Code.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.lvl_953Code.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("rat"), gdjs.lvl_953Code.GDratObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects2.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDratObjects2[i].getVariableNumber(gdjs.lvl_953Code.GDratObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects2[k] = gdjs.lvl_953Code.GDratObjects2[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDratObjects2 */
{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects2[i].getBehavior("Animation").setAnimationName("death");
}
}{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects2.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects2[i].activateBehavior("PlatformerObject", false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("rat"), gdjs.lvl_953Code.GDratObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_953Code.GDratObjects1.length;i<l;++i) {
    if ( gdjs.lvl_953Code.GDratObjects1[i].getBehavior("Animation").getAnimationName() == "death" ) {
        isConditionTrue_0 = true;
        gdjs.lvl_953Code.GDratObjects1[k] = gdjs.lvl_953Code.GDratObjects1[i];
        ++k;
    }
}
gdjs.lvl_953Code.GDratObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDratObjects1 */
{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDkeyObjects1Objects = Hashtable.newFrom({"key": gdjs.lvl_953Code.GDkeyObjects1});
gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.lvl_953Code.GDplayerObjects1});
gdjs.lvl_953Code.asyncCallback14394020 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvl_953Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main_menu", false);
}}
gdjs.lvl_953Code.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvl_953Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.lvl_953Code.asyncCallback14394020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.lvl_953Code.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("key"), gdjs.lvl_953Code.GDkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDkeyObjects1Objects, gdjs.lvl_953Code.mapOfGDgdjs_9546lvl_9595953Code_9546GDplayerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_953Code.GDkeyObjects1 */
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "New sound effect3", 1, false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("Sound")), 1);
}{for(var i = 0, len = gdjs.lvl_953Code.GDkeyObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDkeyObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.lvl_953Code.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.lvl_953Code.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14395580);
}
}
if (isConditionTrue_0) {
}

}


};gdjs.lvl_953Code.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects1);
{for(var i = 0, len = gdjs.lvl_953Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDplayerObjects1[i].getBehavior("Animation").setAnimationName("death");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "death_scene", false);
}}

}


};gdjs.lvl_953Code.eventsList25 = function(runtimeScene) {

{



}


{


gdjs.lvl_953Code.eventsList5(runtimeScene);
}


{


gdjs.lvl_953Code.eventsList6(runtimeScene);
}


{


gdjs.lvl_953Code.eventsList9(runtimeScene);
}


{


gdjs.lvl_953Code.eventsList12(runtimeScene);
}


{


gdjs.lvl_953Code.eventsList14(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("rat"), gdjs.lvl_953Code.GDratObjects1);
{for(var i = 0, len = gdjs.lvl_953Code.GDratObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDratObjects1[i].returnVariable(gdjs.lvl_953Code.GDratObjects1[i].getVariables().getFromIndex(0)).setNumber(3);
}
}}

}


{


gdjs.lvl_953Code.eventsList19(runtimeScene);
}


{


gdjs.lvl_953Code.eventsList20(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("collision"), gdjs.lvl_953Code.GDcollisionObjects1);
{for(var i = 0, len = gdjs.lvl_953Code.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.lvl_953Code.GDcollisionObjects1[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.lvl_953Code.GDplayerObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.lvl_953Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.lvl_953Code.GDplayerObjects1[0].getPointX("")), 0.2), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.lvl_953Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.lvl_953Code.GDplayerObjects1[0].getPointY("")), 0.2), "", 0);
}}

}


{



}


{


gdjs.lvl_953Code.eventsList22(runtimeScene);
}


{


gdjs.lvl_953Code.eventsList23(runtimeScene);
}


{


gdjs.lvl_953Code.eventsList24(runtimeScene);
}


};

gdjs.lvl_953Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvl_953Code.GDlvl_95953Objects1.length = 0;
gdjs.lvl_953Code.GDlvl_95953Objects2.length = 0;
gdjs.lvl_953Code.GDlvl_95953Objects3.length = 0;
gdjs.lvl_953Code.GDlvl_95953Objects4.length = 0;
gdjs.lvl_953Code.GDlvl_95953Objects5.length = 0;
gdjs.lvl_953Code.GDlvl_95953_9595textObjects1.length = 0;
gdjs.lvl_953Code.GDlvl_95953_9595textObjects2.length = 0;
gdjs.lvl_953Code.GDlvl_95953_9595textObjects3.length = 0;
gdjs.lvl_953Code.GDlvl_95953_9595textObjects4.length = 0;
gdjs.lvl_953Code.GDlvl_95953_9595textObjects5.length = 0;
gdjs.lvl_953Code.GDplayer_9595hudObjects1.length = 0;
gdjs.lvl_953Code.GDplayer_9595hudObjects2.length = 0;
gdjs.lvl_953Code.GDplayer_9595hudObjects3.length = 0;
gdjs.lvl_953Code.GDplayer_9595hudObjects4.length = 0;
gdjs.lvl_953Code.GDplayer_9595hudObjects5.length = 0;
gdjs.lvl_953Code.GDlife_9595hudObjects1.length = 0;
gdjs.lvl_953Code.GDlife_9595hudObjects2.length = 0;
gdjs.lvl_953Code.GDlife_9595hudObjects3.length = 0;
gdjs.lvl_953Code.GDlife_9595hudObjects4.length = 0;
gdjs.lvl_953Code.GDlife_9595hudObjects5.length = 0;
gdjs.lvl_953Code.GDEnergyBarObjects1.length = 0;
gdjs.lvl_953Code.GDEnergyBarObjects2.length = 0;
gdjs.lvl_953Code.GDEnergyBarObjects3.length = 0;
gdjs.lvl_953Code.GDEnergyBarObjects4.length = 0;
gdjs.lvl_953Code.GDEnergyBarObjects5.length = 0;
gdjs.lvl_953Code.GDPortraitBackroundObjects1.length = 0;
gdjs.lvl_953Code.GDPortraitBackroundObjects2.length = 0;
gdjs.lvl_953Code.GDPortraitBackroundObjects3.length = 0;
gdjs.lvl_953Code.GDPortraitBackroundObjects4.length = 0;
gdjs.lvl_953Code.GDPortraitBackroundObjects5.length = 0;
gdjs.lvl_953Code.GDbackgroundObjects1.length = 0;
gdjs.lvl_953Code.GDbackgroundObjects2.length = 0;
gdjs.lvl_953Code.GDbackgroundObjects3.length = 0;
gdjs.lvl_953Code.GDbackgroundObjects4.length = 0;
gdjs.lvl_953Code.GDbackgroundObjects5.length = 0;
gdjs.lvl_953Code.GDSpikesObjects1.length = 0;
gdjs.lvl_953Code.GDSpikesObjects2.length = 0;
gdjs.lvl_953Code.GDSpikesObjects3.length = 0;
gdjs.lvl_953Code.GDSpikesObjects4.length = 0;
gdjs.lvl_953Code.GDSpikesObjects5.length = 0;
gdjs.lvl_953Code.GDplayerObjects1.length = 0;
gdjs.lvl_953Code.GDplayerObjects2.length = 0;
gdjs.lvl_953Code.GDplayerObjects3.length = 0;
gdjs.lvl_953Code.GDplayerObjects4.length = 0;
gdjs.lvl_953Code.GDplayerObjects5.length = 0;
gdjs.lvl_953Code.GDkeyObjects1.length = 0;
gdjs.lvl_953Code.GDkeyObjects2.length = 0;
gdjs.lvl_953Code.GDkeyObjects3.length = 0;
gdjs.lvl_953Code.GDkeyObjects4.length = 0;
gdjs.lvl_953Code.GDkeyObjects5.length = 0;
gdjs.lvl_953Code.GDcollisionObjects1.length = 0;
gdjs.lvl_953Code.GDcollisionObjects2.length = 0;
gdjs.lvl_953Code.GDcollisionObjects3.length = 0;
gdjs.lvl_953Code.GDcollisionObjects4.length = 0;
gdjs.lvl_953Code.GDcollisionObjects5.length = 0;
gdjs.lvl_953Code.GDCollisionCheckObjects1.length = 0;
gdjs.lvl_953Code.GDCollisionCheckObjects2.length = 0;
gdjs.lvl_953Code.GDCollisionCheckObjects3.length = 0;
gdjs.lvl_953Code.GDCollisionCheckObjects4.length = 0;
gdjs.lvl_953Code.GDCollisionCheckObjects5.length = 0;
gdjs.lvl_953Code.GDratObjects1.length = 0;
gdjs.lvl_953Code.GDratObjects2.length = 0;
gdjs.lvl_953Code.GDratObjects3.length = 0;
gdjs.lvl_953Code.GDratObjects4.length = 0;
gdjs.lvl_953Code.GDratObjects5.length = 0;
gdjs.lvl_953Code.GDrat_9595attackObjects1.length = 0;
gdjs.lvl_953Code.GDrat_9595attackObjects2.length = 0;
gdjs.lvl_953Code.GDrat_9595attackObjects3.length = 0;
gdjs.lvl_953Code.GDrat_9595attackObjects4.length = 0;
gdjs.lvl_953Code.GDrat_9595attackObjects5.length = 0;
gdjs.lvl_953Code.GDMenu_9595backgroundObjects1.length = 0;
gdjs.lvl_953Code.GDMenu_9595backgroundObjects2.length = 0;
gdjs.lvl_953Code.GDMenu_9595backgroundObjects3.length = 0;
gdjs.lvl_953Code.GDMenu_9595backgroundObjects4.length = 0;
gdjs.lvl_953Code.GDMenu_9595backgroundObjects5.length = 0;

gdjs.lvl_953Code.eventsList25(runtimeScene);

return;

}

gdjs['lvl_953Code'] = gdjs.lvl_953Code;
